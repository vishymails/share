package com.ibm.repository;


import org.springframework.data.repository.CrudRepository;

import com.ibm.model.*;


public interface CarMongoRepository extends CrudRepository<Car, String> {

}
